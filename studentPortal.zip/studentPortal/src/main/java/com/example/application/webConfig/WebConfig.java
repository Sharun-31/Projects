package com.example.application.webConfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
@Configuration
@EnableWebSecurity
public class WebConfig {

	@Autowired
	private StudentDetailService studentDetailsService;

	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
		System.out.println("Details of the data by dao"+studentDetailsService);

		provider.setUserDetailsService(studentDetailsService);
		provider.setPasswordEncoder(passwordEncoder());
		return provider;
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
	    http
	        .authorizeHttpRequests(authorize -> authorize
	            .requestMatchers("/welcome", "/newStudent", "/Student", "/authenticate").permitAll()
	            .requestMatchers("/update/**", "/delete/**").hasAnyAuthority("admin", "Admin")
	            .requestMatchers("/data").hasAnyAuthority("user", "User", "admin", "Admin")
	            .anyRequest().authenticated()
	        )
	        .formLogin(form -> form
	            .loginPage("/welcome")
	            .loginProcessingUrl("/authenticate")
	            .usernameParameter("Email")
	            .passwordParameter("Password")
	            .defaultSuccessUrl("/data")
	        )
	        .exceptionHandling(except -> except
	            .accessDeniedHandler((request, response, accessDeniedException) ->
	                response.sendRedirect("/denied"))
	        )
	        .csrf(csrf -> csrf.disable())
	        .httpBasic(httpBasic -> httpBasic.disable());

	    return http.build();
	}
}