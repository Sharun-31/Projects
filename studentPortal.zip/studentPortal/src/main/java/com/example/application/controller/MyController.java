package com.example.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.application.Repo.StudentRepo;
import com.example.application.entity.StudentManagement;
import java.util.*;
import jakarta.servlet.http.HttpSession;

@Controller
public class MyController {

	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

	@Autowired
	private StudentRepo userrepo;

	private String role;

	@GetMapping("/welcome")
	public String homePage() {
		System.out.println("Login Page Loaded");
		return "welcome.html";
	}

	@GetMapping("/newStudent")
	public String newStudent() {
		System.out.println("Registration Page Loaded");
		return "newStudent.html";
	}

	@GetMapping("/Student")
	public String addingToDB(StudentManagement user, HttpSession session) {
		System.out.println("adding values to Database...........");
		String valid=user.getEmail();
		
		List<StudentManagement> dataList1 = userrepo.findAll();
		for(StudentManagement data:dataList1) {
			
			if(valid.equals(data.getEmail())) {
				System.out.println("if statement for valid");
				session.setAttribute("message", "Failed due to Email Already Exits :" + user.getEmail ());

				return "redirect:/newStudent";
			}
		}
		System.out.println("email entered in the registration :"+valid);
		StudentManagement savedUser = userrepo.save(user);
		session.setAttribute("message", " successfully added" + user.getName());

		System.out.println(savedUser);
		return "redirect:/data";
		
		

	}

	@GetMapping("/update/{id}")
	public String showEditForm(@PathVariable int id, Model model, StudentManagement data) {
		data = userrepo.getReferenceById(id);
		System.out.println("Updated Page Loaded ");

		model.addAttribute("data", data);
		return "update.html";
	}

	@PostMapping("/value")
	public String updatevalues(@ModelAttribute StudentManagement user, HttpSession session) {
		System.out.println("value");
		StudentManagement updateUser = userrepo.save(user);
		System.out.println(updateUser);
		session.setAttribute("message", "Student data Has Been Updated for  :" + updateUser.getName());
		System.out.println("Student data Has Been Updated for  : " + updateUser.getName());
		return "redirect:/data";
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable int id, HttpSession session) {
		userrepo.deleteById(id);
		session.setAttribute("message", "Student data Has Been Deleted for id :" + id);

		System.out.println("Student has Been Deleted From Data Base : " + id);
		return "redirect:/data";
	}

	@GetMapping("/data")
	public String viewStudent(Model model, @AuthenticationPrincipal(expression = "getUsername") String loggedInEmail) {

		StudentManagement dataList = userrepo.findAllByemail(loggedInEmail);

		System.out.println(dataList.getRole() + " : role");
		role = dataList.getRole();

		if (role.equals("User")) {
			model.addAttribute("dataList", dataList);
			model.addAttribute("isUser", true);
			return "viewStudent.html";
		} else {
			List<StudentManagement> dataList1 = userrepo.findAll();
			System.out.println("Data Page Loaded");
			model.addAttribute("dataList", dataList1);
			model.addAttribute("isAdmin", true);
			return "viewStudent.html";
		}

	}

	@GetMapping("/denied")
	public String denided() {

		return "acess.html";
	}

}
