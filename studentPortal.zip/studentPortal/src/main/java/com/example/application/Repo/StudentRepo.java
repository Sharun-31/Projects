package com.example.application.Repo;

import com.example.application.entity.StudentManagement;


import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepo extends JpaRepository<StudentManagement, Integer> {


	StudentManagement findByemail(String email);
	StudentManagement findAllByemail(String loggedInEmail);

}